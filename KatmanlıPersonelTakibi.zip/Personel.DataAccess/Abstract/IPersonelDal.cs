﻿using Personel.Entites.Concrete;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Personel.DataAccess.Abstract
{
    public interface IPersonelDal:IentityRepository<Personell>
    {
       

    }
}
